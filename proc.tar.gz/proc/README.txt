PARTIAL PROC SNAPSHOT - INSTRUCTOR ACCEPTANCE PENDING
This is a snapshot of selected files, not a full /proc backup.
Files were captured sequentially, not atomically.
particion duplicates the captured partitions file.
No file was created inside the live /proc filesystem.
Instructor approval of this alternative is still pending.
