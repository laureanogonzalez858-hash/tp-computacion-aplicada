#!/bin/bash

set -e
umask 077

if [ "${1:-}" = "-help" ]; then
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi

if [ "$#" -ne 2 ]; then
    echo "Error: indicar origen y destino. Usar -help."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ] || [ ! -r "$ORIGEN" ]; then
    echo "Error: origen no disponible."
    exit 1
fi

if [ "$ORIGEN" = "/www_dir" ] && ! mountpoint -q /www_dir; then
    echo "Error: /www_dir no esta montado."
    exit 1
fi

if [ ! -d "$DESTINO" ] || ! mountpoint -q "$DESTINO"; then
    echo "Error: destino no disponible o no montado."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"

echo "Backup creado: $ARCHIVO"
